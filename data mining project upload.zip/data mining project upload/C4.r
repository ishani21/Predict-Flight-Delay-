library(RWeka)
# load data
data<-read.csv("C:/Users/nirav/Desktop/Data Mining/KaranTrain.csv")
data16<-read.csv("C:/Users/nirav/Desktop/Data Mining/KaranTest.csv")
#Factorizing Data
data[,2:48]<-lapply(data[,2:48],factor)
data16[,2:48]<-lapply(data16[,2:48],factor)
#Fit data
fit <- J48(ARR_DEL5~., data)
#Plotting Tree
plot(fit,type="simple")
#Making predictions
predictions <- predict(fit, data16[,-2])
#Summarizing accuracy
table(predictions, data16[,2])