#Read the data and:
#???Store every fifth record in a "test" dataset starting with the first record

library(class)
library(kknn)
library(tree)
test<-read.csv("Test.csv")



#Store the rest in the "training" dataset
train <- read.csv("Train.csv")
train
output1<- knn(train[,-2],test[,-2],train[,2],k=1)

table(output1,test[,2])

output5<- knn(train[,-2],test[,-2],train[,2],k=5)

table(output5,test[,2])
output10<- knn(train[,-2],test[,-2],train[,2],k=10)

table(output10,test[,2])

output15<- knn(train[,-2],test[,-2],train[,2],k=15)

table(output15,test[,2])

output2<- knn(train[,-2],test[,-2],train[,2],k=2)

table(output2,test[,2])

output20<- knn(train[,-2],test[,-2],train[,2],k=20)

table(output20,test[,2])

output25<- knn(train[,-2],test[,-2],train[,2],k=25)

table(output25,test[,2])

kkknnn<-kknn(formula=ARR_DEL5~.,train,test,distance = 1,k=25)
#kkknnn<-ifelse(kkknnn>0.5,1,0)
?fitted
val.fitted<-fitted(kkknnn)
val.fitted<-ifelse(val.fitted>0.5,1,0)
table(Predict=val.fitted,Test=test[,2])

set.seed(2)
target<-test[,2]

attach(train)
attach(test)
head(train)

treemodel<-tree(ARR_DEL5~.,train)
plot(treemodel)
text(treemodel,pretty = 0)

