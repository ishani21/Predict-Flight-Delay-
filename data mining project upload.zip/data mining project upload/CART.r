library(party)
#Fetching Data
data<-read.csv("C:/Users/nirav/Desktop/Data Mining/KaranTrain.csv")
data16<-read.csv("C:/Users/nirav/Desktop/Data Mining/KaranTest.csv")
#Generating CART Decision Tree
ctree<-ctree(ARR_DEL5~.,data)
summary(ctree)
#Ploting Tree
plot(ctree,type="simple")
#Making predictions
predictions <- predict(ctree, data16[,-2])
predictions<-ifelse(predictions>0.33,1,0)
# summarize accuracy
table(predictions, data16[,2])